package com.mphasis.skywaysairline.userservice.exception;

public class GlobalExceptionHandler {

}
