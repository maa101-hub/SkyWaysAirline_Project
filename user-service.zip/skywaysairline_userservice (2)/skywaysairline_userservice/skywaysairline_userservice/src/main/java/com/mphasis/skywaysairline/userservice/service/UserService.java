package com.mphasis.skywaysairline.userservice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.mphasis.skywaysairline.userservice.dto.LoginRequest;
import com.mphasis.skywaysairline.userservice.dto.RegisterRequest;
import com.mphasis.skywaysairline.userservice.model.UserCredentials;
import com.mphasis.skywaysairline.userservice.model.UserProfile;
import com.mphasis.skywaysairline.userservice.repo.UserCredentialsRepository;
import com.mphasis.skywaysairline.userservice.repo.UserProfileRepository;
import com.mphasis.skywaysairline.userservice.security.JwtUtil;
 
@Service
public class UserService {
	
	@Autowired
	private PasswordEncoder passwordEncoder;
    @Autowired
    private UserProfileRepository profileRepo;

    @Autowired
    private UserCredentialsRepository credentialsRepo;
    @Autowired
    private JwtUtil jwtUtil;
    public String register(RegisterRequest request) {

        // Create Profile
        UserProfile profile = new UserProfile();
        profile.setUserId(request.getUserId());
        profile.setFirstName(request.getFirstName());
        profile.setLastName(request.getLastName());
        profile.setDob(request.getDob());
        profile.setGender(request.getGender());
        profile.setAddress(request.getAddress());
        profile.setPhone(request.getPhone());
        profile.setEmail(request.getEmail());

        // Create Credentials
        UserCredentials credentials = new UserCredentials();
        System.out.println(request.getPassword());
        String encode_password=passwordEncoder.encode(request.getPassword());
        credentials.setPassword(encode_password);
        System.out.println(encode_password);
        
        credentials.setUserType("C"); 
        credentials.setLoginStatus(1);

        // 🔗 Link both
        credentials.setUserProfile(profile);
        profile.setCredentials(credentials);

        // Save (cascade will handle both)
        profileRepo.save(profile);

        return "User Registered Successfully";
    }
    public String login(LoginRequest request) {

        UserCredentials user = credentialsRepo.findByUserProfile_Email(request.getEmail())
                .orElseThrow(() -> new RuntimeException("User not found"));

        if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
            throw new RuntimeException("Invalid password");
        }

        return jwtUtil.generateToken(request.getEmail(), user.getUserType());
    }
}