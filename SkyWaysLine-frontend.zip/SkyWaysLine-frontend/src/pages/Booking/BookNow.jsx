import { useState, useEffect } from "react";
import "./BookNow.css";

const blankPassenger = () => ({
  _key:   Math.random().toString(36).slice(2),
  name:   "",
  gender: "",
  age:    "",
  seatNo: "",
});

export default function BookNow({ flightData = {} }) {
  const autoReservationId = flightData.reservationId || "RES-" + Date.now();
  const autoUserId        = flightData.userId        || "USR-001";
  const autoScheduleId    = flightData.scheduleId    || "SC-001";

  // Start directly at "flying" — no idle/hero page
  const [phase, setPhase]   = useState("flying");
  const [saving, setSaving] = useState(false);

  const [reservation, setReservation] = useState({
    reservationType: "",
    journeyDate:     "",
    noOfSeats:       1,
    totalFare:       "",
    bookingStatus:   1,
  });

  const [passengers, setPassengers] = useState([blankPassenger()]);

  // Auto-advance to form after planes finish
  useEffect(() => {
    const t = setTimeout(() => setPhase("form"), 2200);
    return () => clearTimeout(t);
  }, []);

  const onResChange = (e) => {
    setReservation({ ...reservation, [e.target.name]: e.target.value });
  };

  const addPassenger = () => {
    const next = [...passengers, blankPassenger()];
    setPassengers(next);
    setReservation((r) => ({ ...r, noOfSeats: next.length }));
  };

  const removePassenger = (key) => {
    if (passengers.length === 1) return;
    const next = passengers.filter((p) => p._key !== key);
    setPassengers(next);
    setReservation((r) => ({ ...r, noOfSeats: next.length }));
  };

  const onPassengerChange = (key, field, value) => {
    setPassengers(passengers.map((p) =>
      p._key === key ? { ...p, [field]: value } : p
    ));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setSaving(true);
    setTimeout(() => { setSaving(false); setPhase("done"); }, 1800);
  };

  const handleReset = () => {
    setPhase("flying");
    setSaving(false);
    setReservation({ reservationType:"", journeyDate:"", noOfSeats:1, totalFare:"", bookingStatus:1 });
    setPassengers([blankPassenger()]);
    setTimeout(() => setPhase("form"), 2200);
  };

  const today = new Date().toISOString().split("T")[0];

  return (
    <div className="bn-wrap">

      {/* Sky + clouds always visible */}
      <div className="bn-sky">
        <div className="cloud cl1" /><div className="cloud cl2" />
        <div className="cloud cl3" /><div className="cloud cl4" />
      </div>

      {/* Screen crack lines - appear when tearing */}
      {phase === "flying" && (
        <svg className="crack-lines" viewBox="0 0 100 100" preserveAspectRatio="none">
          <path className="crack crack1" d="M0,30 L25,35 L40,28 L55,40 L70,25 L100,35" />
          <path className="crack crack2" d="M0,50 L20,48 L35,55 L50,45 L65,52 L100,48" />
          <path className="crack crack3" d="M0,70 L30,65 L45,75 L60,68 L80,72 L100,65" />
          <path className="crack crack4" d="M30,0 L35,20 L28,40 L40,60 L25,80 L35,100" />
          <path className="crack crack5" d="M70,0 L65,25 L75,45 L68,65 L72,85 L65,100" />
        </svg>
      )}

      {/* Glass shards - fly away */}
      {phase === "flying" && (
        <div className="shards-container">
          <div className="shard s1" />
          <div className="shard s2" />
          <div className="shard s3" />
          <div className="shard s4" />
          <div className="shard s5" />
          <div className="shard s6" />
          <div className="shard s7" />
          <div className="shard s8" />
        </div>
      )}

      {/* Shockwave - when planes enter */}
      {phase === "flying" && <div className="shockwave" />}

      {/* ══ 3 PLANES flying diagonally ══ */}
      {phase === "flying" && (
        <div className="fly-stage">
          {/* Plane 1 — large, centre */}
          <div className="paper-plane pp1">
            <div className="pp-body" /><div className="pp-wing-top" />
            <div className="pp-wing-bot" /><div className="pp-trail" />
          </div>

          {/* Plane 2 — medium, slightly above */}
          <div className="paper-plane pp2">
            <div className="pp-body" /><div className="pp-wing-top" />
            <div className="pp-wing-bot" /><div className="pp-trail" />
          </div>

          {/* Plane 3 — small, below */}
          <div className="paper-plane pp3">
            <div className="pp-body" /><div className="pp-wing-top" />
            <div className="pp-wing-bot" /><div className="pp-trail" />
          </div>

          <p className="fly-label">SkyWay Airlines</p>
        </div>
      )}

      {/* ══ BOOKING FORM ══ */}
      {(phase === "form" || phase === "done") && (
        <div className="form-stage">
          {phase === "done" ? (
            <div className="success-box">
              <div className="success-plane-icon">✈︎</div>
              <h2>Booking Confirmed!</h2>
              <p className="suc-id">Reservation ID: <strong>{autoReservationId}</strong></p>
              <p className="suc-sub">
                {passengers.length} passenger{passengers.length > 1 ? "s" : ""} booked
                on Schedule <strong>{autoScheduleId}</strong>
              </p>
              <button className="btn-primary" onClick={handleReset}>New Booking</button>
            </div>
          ) : (
            <div className="glass-card form-appear">
              <div className="form-top-bar">
                <span className="form-logo">✈︎ SkyWay</span>
                <h2 className="form-heading">Flight Booking</h2>
              </div>

              <form onSubmit={handleSubmit} noValidate>

                {/* Auto-filled IDs */}
                <div className="auto-ids">
                  <div className="auto-chip">
                    <span className="ac-label">Reservation ID</span>
                    <span className="ac-val">{autoReservationId}</span>
                  </div>
                  <div className="auto-chip">
                    <span className="ac-label">User ID</span>
                    <span className="ac-val">{autoUserId}</span>
                  </div>
                  <div className="auto-chip">
                    <span className="ac-label">Schedule ID</span>
                    <span className="ac-val">{autoScheduleId}</span>
                  </div>
                </div>

                <p className="section-title">Reservation Details</p>

                <div className="fields-grid">
                  <div className="field">
                    <label>Reservation Type</label>
                    <select name="reservationType" value={reservation.reservationType} onChange={onResChange} required>
                      <option value="">Select type</option>
                      <option value="One-Way">One-Way</option>
                      <option value="Round-Trip">Round-Trip</option>
                    </select>
                  </div>
                  <div className="field">
                    <label>Journey Date</label>
                    <input type="date" name="journeyDate" min={today}
                      value={reservation.journeyDate} onChange={onResChange} required />
                  </div>
                  <div className="field">
                    <label>No. of Seats</label>
                    <input type="number" readOnly value={passengers.length} className="readonly-input" />
                  </div>
                  <div className="field">
                    <label>Total Fare (₹)</label>
                    <input type="number" name="totalFare" min="0" placeholder="e.g. 12000"
                      value={reservation.totalFare} onChange={onResChange} />
                  </div>
                </div>

                <div className="passengers-header">
                  <p className="section-title">Passengers</p>
                  <button type="button" className="btn-add-pax" onClick={addPassenger}>
                    + Add Passenger
                  </button>
                </div>

                <div className="passengers-list">
                  {passengers.map((p, idx) => (
                    <div key={p._key} className="pax-card">
                      <div className="pax-card-header">
                        <span className="pax-num">Passenger {idx + 1}</span>
                        {passengers.length > 1 && (
                          <button type="button" className="btn-remove-pax"
                            onClick={() => removePassenger(p._key)}>✕</button>
                        )}
                      </div>
                      <div className="pax-grid">
                        <div className="field">
                          <label>Full Name</label>
                          <input type="text" placeholder="e.g. Rahul Sharma"
                            value={p.name}
                            onChange={(e) => onPassengerChange(p._key, "name", e.target.value)} required />
                        </div>
                        <div className="field">
                          <label>Gender</label>
                          <select value={p.gender}
                            onChange={(e) => onPassengerChange(p._key, "gender", e.target.value)} required>
                            <option value="">Select</option>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                            <option value="Other">Other</option>
                          </select>
                        </div>
                        <div className="field">
                          <label>Age</label>
                          <input type="number" min="1" max="120" placeholder="e.g. 28"
                            value={p.age}
                            onChange={(e) => onPassengerChange(p._key, "age", e.target.value)} required />
                        </div>
                        <div className="field">
                          <label>Seat No.</label>
                          <input type="number" min="1" placeholder="e.g. 14"
                            value={p.seatNo}
                            onChange={(e) => onPassengerChange(p._key, "seatNo", e.target.value)} required />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                <button type="submit" className="btn-primary btn-submit" disabled={saving}>
                  {saving ? (
                    <span className="saving-text">
                      <span className="dot-pulse" /> Confirming Booking...
                    </span>
                  ) : "Confirm Booking ✈"}
                </button>

              </form>
            </div>
          )}
        </div>
      )}
    </div>
  );
}