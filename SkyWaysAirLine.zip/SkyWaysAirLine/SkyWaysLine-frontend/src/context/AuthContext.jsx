import { createContext, useState, useEffect } from "react";
import { jwtDecode } from "jwt-decode";

export const AuthContext = createContext();

const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);

  // ✅ safe decode function
  const decodeToken = (token) => {
    try {
      if (!token || token.split(".").length !== 3) return null;

      const decoded = jwtDecode(token);

      return {
        email: decoded.sub,
        role: decoded.role,
      };
    } catch (err) {
      console.log("Invalid token");
      return null;
    }
  };

  // ✅ load user on refresh
  useEffect(() => {
    const token = localStorage.getItem("token");

    const userData = decodeToken(token);

    if (userData) {
      setUser(userData);
    } else {
      localStorage.removeItem("token");
    }
  }, []);

  // ✅ login
  const login = (token) => {
    const userData = decodeToken(token);

    if (!userData) {
      alert("Invalid token from backend");
      return;
    }

    localStorage.setItem("token", token);
    setUser(userData);
  };

  // ✅ logout
  const logout = () => {
    localStorage.removeItem("token");
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export default AuthProvider;