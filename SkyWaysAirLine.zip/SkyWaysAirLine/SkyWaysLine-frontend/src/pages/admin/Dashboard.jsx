import { useState } from "react";
import "./Dashboard.css";
import { useNavigate } from "react-router-dom";

// ── Initial mock data ─────────────────────────────────────────
const INIT_FLIGHTS = [
  { flightId: "FL001", flightName: "SkyWay Express", seatingCapacity: 180, reservationCapacity: 20 },
  { flightId: "FL002", flightName: "SkyWay Lite",    seatingCapacity: 120, reservationCapacity: 10 },
];

const INIT_ROUTES = [
  { routeId: "RT001", source: "Delhi",  destination: "Mumbai",    distance: 1150, fare: 4599 },
  { routeId: "RT002", source: "Mumbai", destination: "Bangalore", distance: 980,  fare: 3200 },
];

const INIT_SCHEDULES = [
  { scheduleId: "SC001", flightId: "FL001", routeId: "RT001", travelDuration: 130, availableDays: "Mon,Wed,Fri", departureTime: "06:00" },
  { scheduleId: "SC002", flightId: "FL002", routeId: "RT002", travelDuration: 110, availableDays: "Tue,Thu,Sat", departureTime: "09:30" },
];

const DAYS = ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"];

// ── Blank forms ───────────────────────────────────────────────
const blankFlight   = { flightId:"", flightName:"", seatingCapacity:"", reservationCapacity:"" };
const blankRoute    = { routeId:"", source:"", destination:"", distance:"", fare:"" };
const blankSchedule = { scheduleId:"", flightId:"", routeId:"", travelDuration:"", availableDays:"", departureTime:"" };

export default function Dashboard() {
  const nevigate=useNavigate();
  const [tab, setTab] = useState("flights");

  // ── Flights state ─────────────────────────────────────────
  const [flights, setFlights]         = useState(INIT_FLIGHTS);
  const [flightForm, setFlightForm]   = useState(blankFlight);
  const [flightEdit, setFlightEdit]   = useState(null);   // id being edited
  const [flightModal, setFlightModal] = useState(false);
  const [flightDel, setFlightDel]     = useState(null);

  // ── Routes state ──────────────────────────────────────────
  const [routes, setRoutes]         = useState(INIT_ROUTES);
  const [routeForm, setRouteForm]   = useState(blankRoute);
  const [routeEdit, setRouteEdit]   = useState(null);
  const [routeModal, setRouteModal] = useState(false);
  const [routeDel, setRouteDel]     = useState(null);

  // ── Schedules state ───────────────────────────────────────
  const [schedules, setSchedules]         = useState(INIT_SCHEDULES);
  const [scheduleForm, setScheduleForm]   = useState(blankSchedule);
  const [scheduleEdit, setScheduleEdit]   = useState(null);
  const [scheduleModal, setScheduleModal] = useState(false);
  const [scheduleDel, setScheduleDel]     = useState(null);

  // ── Helpers ───────────────────────────────────────────────
  const openAdd = (type) => {
    if (type === "flights")   { setFlightForm(blankFlight);   setFlightEdit(null);   setFlightModal(true); }
    if (type === "routes")    { setRouteForm(blankRoute);     setRouteEdit(null);    setRouteModal(true); }
    if (type === "schedules") { setScheduleForm(blankSchedule); setScheduleEdit(null); setScheduleModal(true); }
  };

  // ── FLIGHT CRUD ───────────────────────────────────────────
  const saveFlight = () => {
    const { flightId, flightName, seatingCapacity } = flightForm;
    if (!flightId || !flightName || !seatingCapacity) { alert("Fill all required fields."); return; }
    if (flightEdit) {
      setFlights(flights.map(f => f.flightId === flightEdit ? { ...flightForm } : f));
    } else {
      if (flights.find(f => f.flightId === flightId)) { alert("Flight ID already exists."); return; }
      setFlights([...flights, { ...flightForm }]);
    }
    setFlightModal(false);
  };
  const editFlight = (f) => { setFlightForm({ ...f }); setFlightEdit(f.flightId); setFlightModal(true); };
  const deleteFlight = () => { setFlights(flights.filter(f => f.flightId !== flightDel)); setFlightDel(null); };

  // ── ROUTE CRUD ────────────────────────────────────────────
  const saveRoute = () => {
    const { routeId, source, destination, distance } = routeForm;
    if (!routeId || !source || !destination || !distance) { alert("Fill all required fields."); return; }
    if (routeEdit) {
      setRoutes(routes.map(r => r.routeId === routeEdit ? { ...routeForm } : r));
    } else {
      if (routes.find(r => r.routeId === routeId)) { alert("Route ID already exists."); return; }
      setRoutes([...routes, { ...routeForm }]);
    }
    setRouteModal(false);
  };
  const editRoute = (r) => { setRouteForm({ ...r }); setRouteEdit(r.routeId); setRouteModal(true); };
  const deleteRoute = () => { setRoutes(routes.filter(r => r.routeId !== routeDel)); setRouteDel(null); };

  // ── SCHEDULE CRUD ─────────────────────────────────────────
  const toggleDay = (day) => {
    const days = scheduleForm.availableDays ? scheduleForm.availableDays.split(",") : [];
    const next = days.includes(day) ? days.filter(d => d !== day) : [...days, day];
    setScheduleForm({ ...scheduleForm, availableDays: next.join(",") });
  };
  const saveSchedule = () => {
    const { scheduleId, flightId, routeId, travelDuration, availableDays, departureTime } = scheduleForm;
    if (!scheduleId || !flightId || !routeId || !travelDuration || !availableDays || !departureTime) {
      alert("Fill all required fields."); return;
    }
    if (scheduleEdit) {
      setSchedules(schedules.map(s => s.scheduleId === scheduleEdit ? { ...scheduleForm } : s));
    } else {
      if (schedules.find(s => s.scheduleId === scheduleId)) { alert("Schedule ID already exists."); return; }
      setSchedules([...schedules, { ...scheduleForm }]);
    }
    setScheduleModal(false);
  };
  const editSchedule = (s) => { setScheduleForm({ ...s }); setScheduleEdit(s.scheduleId); setScheduleModal(true); };
  const deleteSchedule = () => { setSchedules(schedules.filter(s => s.scheduleId !== scheduleDel)); setScheduleDel(null); };

  return (
    <div className="dash-bg">
      <div className="stars" />

      {/* ── SIDEBAR ── */}
      <aside className="sidebar">
        <div className="sidebar-logo">✈︎ Sky<span>Way</span></div>
        <p className="sidebar-role">Admin Panel</p>
        <nav className="sidebar-nav">
          <button className={`s-link ${tab==="flights"?"active":""}`}   onClick={()=>setTab("flights")}>
            <span className="s-icon">✈</span> Flights
          </button>
          <button className={`s-link ${tab==="routes"?"active":""}`}    onClick={()=>setTab("routes")}>
            <span className="s-icon">🗺</span> Routes
          </button>
          <button className={`s-link ${tab==="schedules"?"active":""}`} onClick={()=>setTab("schedules")}>
            <span className="s-icon">📅</span> Schedules
          </button>
        </nav>
        <div className="sidebar-bottom">
          <button className="logout-side" onClick={()=>{ if(window.confirm("Logout?")) alert("Logged out!") 
            nevigate("/login"); }}>
            ⎋ Logout
          </button>
        </div>
      </aside>

      {/* ── MAIN ── */}
      <main className="dash-main">

        {/* ─── FLIGHTS TAB ─────────────────────────────── */}
        {tab === "flights" && (
          <div className="tab-content">
            <div className="tab-header">
              <div>
                <h1 className="tab-title">Flights</h1>
                <p className="tab-sub">Manage your fleet of aircraft</p>
              </div>
              <button className="btn-add" onClick={()=>openAdd("flights")}>+ Add Flight</button>
            </div>

            {/* Stats row */}
            <div className="stats-row">
              <div className="stat-card">
                <p className="stat-num">{flights.length}</p>
                <p className="stat-label">Total Flights</p>
              </div>
              <div className="stat-card">
                <p className="stat-num">{flights.reduce((a,f)=>a+Number(f.seatingCapacity),0)}</p>
                <p className="stat-label">Total Seats</p>
              </div>
              <div className="stat-card">
                <p className="stat-num">{flights.reduce((a,f)=>a+Number(f.reservationCapacity||0),0)}</p>
                <p className="stat-label">Reserved Seats</p>
              </div>
            </div>

            <div className="table-wrap">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Flight ID</th>
                    <th>Flight Name</th>
                    <th>Seating Capacity</th>
                    <th>Reservation Capacity</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {flights.length === 0 && (
                    <tr><td colSpan="5" className="empty-row">No flights added yet.</td></tr>
                  )}
                  {flights.map(f => (
                    <tr key={f.flightId}>
                      <td><span className="id-badge">{f.flightId}</span></td>
                      <td><strong>{f.flightName}</strong></td>
                      <td>{f.seatingCapacity}</td>
                      <td>{f.reservationCapacity || "—"}</td>
                      <td>
                        <div className="action-btns">
                          <button className="btn-edit"   onClick={()=>editFlight(f)}>✏ Edit</button>
                          <button className="btn-delete" onClick={()=>setFlightDel(f.flightId)}>🗑 Delete</button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ─── ROUTES TAB ──────────────────────────────── */}
        {tab === "routes" && (
          <div className="tab-content">
            <div className="tab-header">
              <div>
                <h1 className="tab-title">Routes</h1>
                <p className="tab-sub">Configure source–destination routes</p>
              </div>
              <button className="btn-add" onClick={()=>openAdd("routes")}>+ Add Route</button>
            </div>

            <div className="stats-row">
              <div className="stat-card">
                <p className="stat-num">{routes.length}</p>
                <p className="stat-label">Total Routes</p>
              </div>
              <div className="stat-card">
                <p className="stat-num">{routes.reduce((a,r)=>a+Number(r.distance),0).toLocaleString()} km</p>
                <p className="stat-label">Total Distance</p>
              </div>
              <div className="stat-card">
                <p className="stat-num">₹{routes.length ? Math.min(...routes.map(r=>r.fare)).toLocaleString("en-IN") : 0}</p>
                <p className="stat-label">Min Fare</p>
              </div>
            </div>

            <div className="table-wrap">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Route ID</th>
                    <th>Source</th>
                    <th>Destination</th>
                    <th>Distance (km)</th>
                    <th>Fare (₹)</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {routes.length === 0 && (
                    <tr><td colSpan="6" className="empty-row">No routes added yet.</td></tr>
                  )}
                  {routes.map(r => (
                    <tr key={r.routeId}>
                      <td><span className="id-badge">{r.routeId}</span></td>
                      <td>🛫 {r.source}</td>
                      <td>🛬 {r.destination}</td>
                      <td>{Number(r.distance).toLocaleString()}</td>
                      <td>₹{Number(r.fare).toLocaleString("en-IN")}</td>
                      <td>
                        <div className="action-btns">
                          <button className="btn-edit"   onClick={()=>editRoute(r)}>✏ Edit</button>
                          <button className="btn-delete" onClick={()=>setRouteDel(r.routeId)}>🗑 Delete</button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ─── SCHEDULES TAB ───────────────────────────── */}
        {tab === "schedules" && (
          <div className="tab-content">
            <div className="tab-header">
              <div>
                <h1 className="tab-title">Schedules</h1>
                <p className="tab-sub">Assign flights to routes with timings</p>
              </div>
              <button className="btn-add" onClick={()=>openAdd("schedules")}>+ Add Schedule</button>
            </div>

            <div className="stats-row">
              <div className="stat-card">
                <p className="stat-num">{schedules.length}</p>
                <p className="stat-label">Total Schedules</p>
              </div>
              <div className="stat-card">
                <p className="stat-num">{[...new Set(schedules.map(s=>s.flightId))].length}</p>
                <p className="stat-label">Flights Scheduled</p>
              </div>
              <div className="stat-card">
                <p className="stat-num">{[...new Set(schedules.map(s=>s.routeId))].length}</p>
                <p className="stat-label">Routes Active</p>
              </div>
            </div>

            <div className="table-wrap">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Schedule ID</th>
                    <th>Flight ID</th>
                    <th>Route ID</th>
                    <th>Duration (min)</th>
                    <th>Available Days</th>
                    <th>Departure</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {schedules.length === 0 && (
                    <tr><td colSpan="7" className="empty-row">No schedules added yet.</td></tr>
                  )}
                  {schedules.map(s => (
                    <tr key={s.scheduleId}>
                      <td><span className="id-badge">{s.scheduleId}</span></td>
                      <td>{s.flightId}</td>
                      <td>{s.routeId}</td>
                      <td>{s.travelDuration} min</td>
                      <td>
                        <div className="day-chips">
                          {s.availableDays.split(",").map(d=>(
                            <span key={d} className="day-chip">{d}</span>
                          ))}
                        </div>
                      </td>
                      <td><span className="time-badge">{s.departureTime}</span></td>
                      <td>
                        <div className="action-btns">
                          <button className="btn-edit"   onClick={()=>editSchedule(s)}>✏ Edit</button>
                          <button className="btn-delete" onClick={()=>setScheduleDel(s.scheduleId)}>🗑 Delete</button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </main>

      {/* ════════════ MODALS ════════════ */}

      {/* ── Flight Modal ── */}
      {flightModal && (
        <div className="modal-overlay" onClick={()=>setFlightModal(false)}>
          <div className="modal" onClick={e=>e.stopPropagation()}>
            <div className="modal-header">
              <h2>{flightEdit ? "Edit Flight" : "Add Flight"}</h2>
              <button className="modal-close" onClick={()=>setFlightModal(false)}>✕</button>
            </div>
            <div className="modal-body">
              <div className="form-row-2">
                <div className="field">
                  <label>Flight ID <span className="req">*</span></label>
                  <input
                    placeholder="e.g. FL003"
                    value={flightForm.flightId}
                    disabled={!!flightEdit}
                    onChange={e=>setFlightForm({...flightForm, flightId:e.target.value})}
                  />
                </div>
                <div className="field">
                  <label>Flight Name <span className="req">*</span></label>
                  <input
                    placeholder="e.g. SkyWay Premium"
                    value={flightForm.flightName}
                    onChange={e=>setFlightForm({...flightForm, flightName:e.target.value})}
                  />
                </div>
              </div>
              <div className="form-row-2">
                <div className="field">
                  <label>Seating Capacity <span className="req">*</span></label>
                  <input
                    type="number" min="1" placeholder="e.g. 180"
                    value={flightForm.seatingCapacity}
                    onChange={e=>setFlightForm({...flightForm, seatingCapacity:e.target.value})}
                  />
                </div>
                <div className="field">
                  <label>Reservation Capacity</label>
                  <input
                    type="number" min="0" placeholder="e.g. 20"
                    value={flightForm.reservationCapacity}
                    onChange={e=>setFlightForm({...flightForm, reservationCapacity:e.target.value})}
                  />
                </div>
              </div>
            </div>
            <div className="modal-footer">
              <button className="btn-cancel" onClick={()=>setFlightModal(false)}>Cancel</button>
              <button className="btn-save"   onClick={saveFlight}>{flightEdit ? "Update" : "Add Flight"}</button>
            </div>
          </div>
        </div>
      )}

      {/* ── Route Modal ── */}
      {routeModal && (
        <div className="modal-overlay" onClick={()=>setRouteModal(false)}>
          <div className="modal" onClick={e=>e.stopPropagation()}>
            <div className="modal-header">
              <h2>{routeEdit ? "Edit Route" : "Add Route"}</h2>
              <button className="modal-close" onClick={()=>setRouteModal(false)}>✕</button>
            </div>
            <div className="modal-body">
              <div className="field">
                <label>Route ID <span className="req">*</span></label>
                <input
                  placeholder="e.g. RT003"
                  value={routeForm.routeId}
                  disabled={!!routeEdit}
                  onChange={e=>setRouteForm({...routeForm, routeId:e.target.value})}
                />
              </div>
              <div className="form-row-2">
                <div className="field">
                  <label>Source <span className="req">*</span></label>
                  <input
                    placeholder="e.g. Delhi"
                    value={routeForm.source}
                    onChange={e=>setRouteForm({...routeForm, source:e.target.value})}
                  />
                </div>
                <div className="field">
                  <label>Destination <span className="req">*</span></label>
                  <input
                    placeholder="e.g. Mumbai"
                    value={routeForm.destination}
                    onChange={e=>setRouteForm({...routeForm, destination:e.target.value})}
                  />
                </div>
              </div>
              <div className="form-row-2">
                <div className="field">
                  <label>Distance (km) <span className="req">*</span></label>
                  <input
                    type="number" min="1" placeholder="e.g. 1150"
                    value={routeForm.distance}
                    onChange={e=>setRouteForm({...routeForm, distance:e.target.value})}
                  />
                </div>
                <div className="field">
                  <label>Fare (₹)</label>
                  <input
                    type="number" min="0" placeholder="e.g. 4599"
                    value={routeForm.fare}
                    onChange={e=>setRouteForm({...routeForm, fare:e.target.value})}
                  />
                </div>
              </div>
            </div>
            <div className="modal-footer">
              <button className="btn-cancel" onClick={()=>setRouteModal(false)}>Cancel</button>
              <button className="btn-save"   onClick={saveRoute}>{routeEdit ? "Update" : "Add Route"}</button>
            </div>
          </div>
        </div>
      )}

      {/* ── Schedule Modal ── */}
      {scheduleModal && (
        <div className="modal-overlay" onClick={()=>setScheduleModal(false)}>
          <div className="modal modal-lg" onClick={e=>e.stopPropagation()}>
            <div className="modal-header">
              <h2>{scheduleEdit ? "Edit Schedule" : "Add Schedule"}</h2>
              <button className="modal-close" onClick={()=>setScheduleModal(false)}>✕</button>
            </div>
            <div className="modal-body">
              <div className="field">
                <label>Schedule ID <span className="req">*</span></label>
                <input
                  placeholder="e.g. SC003"
                  value={scheduleForm.scheduleId}
                  disabled={!!scheduleEdit}
                  onChange={e=>setScheduleForm({...scheduleForm, scheduleId:e.target.value})}
                />
              </div>
              <div className="form-row-2">
                <div className="field">
                  <label>Flight ID <span className="req">*</span></label>
                  <select
                    value={scheduleForm.flightId}
                    onChange={e=>setScheduleForm({...scheduleForm, flightId:e.target.value})}
                  >
                    <option value="">Select Flight</option>
                    {flights.map(f=>(
                      <option key={f.flightId} value={f.flightId}>{f.flightId} — {f.flightName}</option>
                    ))}
                  </select>
                </div>
                <div className="field">
                  <label>Route ID <span className="req">*</span></label>
                  <select
                    value={scheduleForm.routeId}
                    onChange={e=>setScheduleForm({...scheduleForm, routeId:e.target.value})}
                  >
                    <option value="">Select Route</option>
                    {routes.map(r=>(
                      <option key={r.routeId} value={r.routeId}>{r.routeId} — {r.source} → {r.destination}</option>
                    ))}
                  </select>
                </div>
              </div>
              <div className="form-row-2">
                <div className="field">
                  <label>Travel Duration (min) <span className="req">*</span></label>
                  <input
                    type="number" min="1" placeholder="e.g. 130"
                    value={scheduleForm.travelDuration}
                    onChange={e=>setScheduleForm({...scheduleForm, travelDuration:e.target.value})}
                  />
                </div>
                <div className="field">
                  <label>Departure Time <span className="req">*</span></label>
                  <input
                    type="time"
                    value={scheduleForm.departureTime}
                    onChange={e=>setScheduleForm({...scheduleForm, departureTime:e.target.value})}
                  />
                </div>
              </div>
              <div className="field">
                <label>Available Days <span className="req">*</span></label>
                <div className="day-picker">
                  {DAYS.map(d => {
                    const selected = scheduleForm.availableDays.split(",").includes(d);
                    return (
                      <button
                        key={d}
                        type="button"
                        className={`day-pick-btn ${selected ? "selected" : ""}`}
                        onClick={()=>toggleDay(d)}
                      >
                        {d}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
            <div className="modal-footer">
              <button className="btn-cancel" onClick={()=>setScheduleModal(false)}>Cancel</button>
              <button className="btn-save"   onClick={saveSchedule}>{scheduleEdit ? "Update" : "Add Schedule"}</button>
            </div>
          </div>
        </div>
      )}

      {/* ── Delete Confirm ── */}
      {(flightDel || routeDel || scheduleDel) && (
        <div className="modal-overlay">
          <div className="modal modal-sm">
            <div className="modal-header">
              <h2>Confirm Delete</h2>
            </div>
            <div className="modal-body">
              <p className="confirm-text">
                Are you sure you want to delete{" "}
                <strong>{flightDel || routeDel || scheduleDel}</strong>?
                This action cannot be undone.
              </p>
            </div>
            <div className="modal-footer">
              <button className="btn-cancel" onClick={()=>{ setFlightDel(null); setRouteDel(null); setScheduleDel(null); }}>
                Cancel
              </button>
              <button
                className="btn-danger"
                onClick={()=>{
                  if (flightDel)   deleteFlight();
                  if (routeDel)    deleteRoute();
                  if (scheduleDel) deleteSchedule();
                }}
              >
                🗑 Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}