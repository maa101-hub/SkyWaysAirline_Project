import { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Home.css";

const MOCK_FLIGHTS = [
  {
    id: 1,
    airline: "IndiGo",
    code: "6E-204",
    logo: "6E",
    from: "DEL",
    to: "BOM",
    departure: "06:00",
    arrival: "08:10",
    duration: "2h 10m",
    stops: "Non-stop",
    price: 4599,
    seats: 12,
  },
  {
    id: 2,
    airline: "Air India",
    code: "AI-101",
    logo: "AI",
    from: "DEL",
    to: "BOM",
    departure: "09:30",
    arrival: "11:55",
    duration: "2h 25m",
    stops: "Non-stop",
    price: 6200,
    seats: 4,
  },
  {
    id: 3,
    airline: "SpiceJet",
    code: "SG-112",
    logo: "SG",
    from: "DEL",
    to: "BOM",
    departure: "13:15",
    arrival: "16:00",
    duration: "2h 45m",
    stops: "1 Stop",
    price: 3850,
    seats: 20,
  },
  {
    id: 4,
    airline: "Vistara",
    code: "UK-995",
    logo: "UK",
    from: "DEL",
    to: "BOM",
    departure: "17:45",
    arrival: "19:55",
    duration: "2h 10m",
    stops: "Non-stop",
    price: 7800,
    seats: 6,
  },
  {
    id: 5,
    airline: "IndiGo",
    code: "6E-512",
    logo: "6E",
    from: "DEL",
    to: "BOM",
    departure: "21:00",
    arrival: "23:05",
    duration: "2h 05m",
    stops: "Non-stop",
    price: 4999,
    seats: 9,
  },
];

const AIRLINE_COLORS = {
  "6E": "#1a73e8",
  AI:   "#e63946",
  SG:   "#e07b00",
  UK:   "#6a0dad",
};

export default function Home() {
    const nevigate=useNavigate();
  const [form, setForm] = useState({ from: "", to: "", date: "", passengers: "1" });
  const [flights, setFlights]   = useState([]);
  const [searched, setSearched] = useState(false);
  const [loading, setLoading]   = useState(false);
  const [sortBy, setSortBy]     = useState("price");

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSwap = () => setForm({ ...form, from: form.to, to: form.from });

  const handleSearch = (e) => {
    e.preventDefault();
    if (!form.from || !form.to || !form.date) {
      alert("Please fill in From, To and Date.");
      return;
    }
    if (form.from.toLowerCase() === form.to.toLowerCase()) {
      alert("From and To cannot be the same.");
      return;
    }
    setLoading(true);
    setSearched(false);
    setTimeout(() => {
      setFlights(MOCK_FLIGHTS);
      setSearched(true);
      setLoading(false);
    }, 1200);
  };

  const handleLogout = () => {
    if (window.confirm("Are you sure you want to logout?")) {
      alert("Logged out!");
      nevigate('/login');
      // window.location.href = "/login";
    }
  };

  const sorted = [...flights].sort((a, b) => {
    if (sortBy === "price")     return a.price - b.price;
    if (sortBy === "duration")  return a.duration.localeCompare(b.duration);
    if (sortBy === "departure") return a.departure.localeCompare(b.departure);
    return 0;
  });

  const today = new Date().toISOString().split("T")[0];

  return (
    <div className="home-bg">
      <div className="stars" />

      {/* ── NAVBAR ── */}
      <nav className="home-nav">
        <div className="logo">✈︎ Sky<span>Way</span></div>
        <div className="nav-links">
          <a href="#" className="nav-link active">Flights</a>
          <a href="#" className="nav-link">My Bookings</a>
          <a href="#" className="nav-link">Check-in</a>
        </div>
        <div className="nav-right">
          <div className="user-badge">
            <div className="user-avatar">U</div>
            <span className="user-name">User</span>
          </div>
          <button className="logout-btn" onClick={handleLogout}>
            ⎋ Logout
          </button>
        </div>
      </nav>

      {/* ── HERO + SEARCH ── */}
      <div className="hero">
        <p className="hero-tag">✦ Your journey starts here</p>
        <h1 className="hero-title">
          Where do you want<br />to <span>fly today?</span>
        </h1>

        <div className="search-card">
          <form onSubmit={handleSearch} noValidate>

            {/* Row 1 — From / Swap / To */}
            <div className="route-row">
              <div className="route-field">
                <label>From</label>
                <div className="input-icon-wrap">
                  <span className="field-icon">🛫</span>
                  <input
                    type="text"
                    name="from"
                    placeholder="City or Airport"
                    value={form.from}
                    onChange={handleChange}
                  />
                </div>
              </div>

              <button type="button" className="swap-btn" onClick={handleSwap}>⇌</button>

              <div className="route-field">
                <label>To</label>
                <div className="input-icon-wrap">
                  <span className="field-icon">🛬</span>
                  <input
                    type="text"
                    name="to"
                    placeholder="City or Airport"
                    value={form.to}
                    onChange={handleChange}
                  />
                </div>
              </div>
            </div>

            {/* Row 2 — Date / Passengers / Button */}
            <div className="detail-row">
              <div className="detail-field">
                <label>Departure Date</label>
                <input type="date" name="date" min={today} value={form.date} onChange={handleChange} />
              </div>

              <div className="detail-field">
                <label>Passengers</label>
                <select name="passengers" value={form.passengers} onChange={handleChange}>
                  {[1, 2, 3, 4, 5, 6].map((n) => (
                    <option key={n} value={n}>{n} Passenger{n > 1 ? "s" : ""}</option>
                  ))}
                </select>
              </div>

              <button type="submit" className="search-btn">🔍 Search Flights</button>
            </div>

          </form>
        </div>
      </div>

      {/* ── LOADING ── */}
      {loading && (
        <div className="loading-wrap">
          <div className="plane-loader">✈︎</div>
          <p className="loading-text">Searching best flights for you...</p>
        </div>
      )}

      {/* ── RESULTS ── */}
      {searched && !loading && (
        <div className="results-section">

          {/* Header */}
          <div className="results-header">
            <div className="results-info">
              <span className="count-num">{sorted.length}</span>
              <span className="count-label"> flights found</span>
              <span className="route-tag">
                {form.from} → {form.to} · {form.date} · {form.passengers} Pax
              </span>
            </div>
            <div className="sort-wrap">
              <span className="sort-label">Sort:</span>
              {["price", "duration", "departure"].map((s) => (
                <button
                  key={s}
                  className={`sort-btn ${sortBy === s ? "active" : ""}`}
                  onClick={() => setSortBy(s)}
                >
                  {s.charAt(0).toUpperCase() + s.slice(1)}
                </button>
              ))}
            </div>
          </div>

          {/* Flight list */}
          <div className="flights-list">
            {sorted.map((fl) => (
              <div key={fl.id} className="flight-card">

                {/* Airline */}
                <div className="airline-col">
                  <div className="airline-logo" style={{ background: AIRLINE_COLORS[fl.logo] || "#4fa3e3" }}>
                    {fl.logo}
                  </div>
                  <div>
                    <p className="airline-name">{fl.airline}</p>
                    <p className="flight-code">{fl.code}</p>
                  </div>
                </div>

                {/* Route path */}
                <div className="route-col">
                  <div className="time-block">
                    <p className="time">{fl.departure}</p>
                    <p className="iata">{fl.from}</p>
                  </div>
                  <div className="path-block">
                    <p className="duration">{fl.duration}</p>
                    <div className="path-line">
                      <span className="dot" />
                      <div className="bar" />
                      <span className="plane-mid">✈</span>
                      <div className="bar" />
                      <span className="dot" />
                    </div>
                    <p className={`stops ${fl.stops === "Non-stop" ? "nonstop" : "hasstop"}`}>
                      {fl.stops}
                    </p>
                  </div>
                  <div className="time-block">
                    <p className="time">{fl.arrival}</p>
                    <p className="iata">{fl.to}</p>
                  </div>
                </div>

                {/* Seats */}
                <div className="seats-col">
                  {fl.seats <= 5
                    ? <span className="seats-urgent">Only {fl.seats} left!</span>
                    : <span className="seats-ok">{fl.seats} seats</span>}
                </div>

                {/* Price + Book */}
                <div className="price-col">
                  <p className="per-person">per person</p>
                  <p className="price">₹{fl.price.toLocaleString("en-IN")}</p>
                  <button
                    className="book-btn"
                    onClick={() => alert(`Booking ${fl.code} — ${fl.airline}\n₹${fl.price.toLocaleString("en-IN")} / person`)}
                  >
                    Book Now
                  </button>
                </div>

              </div>
            ))}
          </div>

        </div>
      )}

      {/* ── EMPTY STATE ── */}
      {!searched && !loading && (
        <div className="empty-state">
          <div className="empty-icon">🌏</div>
          <p className="empty-title">Ready for takeoff?</p>
          <p className="empty-sub">Enter your route above to discover available flights.</p>
        </div>
      )}
    </div>
  );
}