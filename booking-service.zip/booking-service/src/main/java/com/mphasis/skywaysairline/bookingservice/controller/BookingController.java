package com.mphasis.skywaysairline.bookingservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mphasis.skywaysairline.bookingservice.dto.BookingRequest;
import com.mphasis.skywaysairline.bookingservice.dto.PaymentConfirmRequest;
import com.mphasis.skywaysairline.bookingservice.dto.TicketResponse;
import com.mphasis.skywaysairline.bookingservice.response.ApiResponse;
import com.mphasis.skywaysairline.bookingservice.service.BookingService;

@RestController
@RequestMapping("/api/booking")
public class BookingController {

    @Autowired
    private BookingService service;

    // 🔹 CREATE PAYMENT ORDER
    @PostMapping("/create-order")
    public ResponseEntity<ApiResponse<String>> createOrder(
            @RequestBody BookingRequest req) {
        String orderId = service.createOrder(req);
        return ResponseEntity.ok(
                new ApiResponse<>("Order created", orderId)
        );
    }

    // 🔥 CONFIRM BOOKING AFTER PAYMENT
    @PostMapping("/confirm")
    public ResponseEntity<ApiResponse<TicketResponse>> confirmBooking(
            @RequestBody PaymentConfirmRequest req) {

        TicketResponse response = service.confirmBooking(req);

        return ResponseEntity.ok(
                new ApiResponse<>("Booking Successful", response)
        );
    }
}