package com.mphasis.skywaysairline.bookingservice.dto;

import jakarta.validation.constraints.NotBlank;

public class PassengerDTO {
	@NotBlank(message="Please provide a name")
	private String name;
    private String gender;
    @NotBlank(message="Please provide a age")
    private int age;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
}
